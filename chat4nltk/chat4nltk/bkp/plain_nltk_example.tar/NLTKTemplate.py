from nltk.chat.util import Chat, reflections

myPairs = (
    #pair 0
    ({STR|RE},    # pattern 0
        (STR_0,   #template 0
         SRT_n)), #template n   
    #pair n    
    ({STR|RE},    #pattern n
     (...)),      #templates    
    )

myBot = Chat(myPairs, reflections)
myBot.converse(quit={pattern $\in$ myPairs}) 
