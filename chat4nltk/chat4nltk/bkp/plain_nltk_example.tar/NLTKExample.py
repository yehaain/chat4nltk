from nltk.chat.util import Chat, reflections

myPairs = (
    #using wild-card for generalization
    ('Hi (.*)', ('Hi', 'Hello')),
    #using wild-card for reflection (%1) and for parametric template (%2)
    (r'(.*) (tired|freezing)',
        ('%1 %2', 
         'Poor %1...',
         'Why did became %2')),
    #quitting chat
    ('Bye', ('See you.', 'Bye')),
    #catch no matches
    (r'(.*)', ('Don\'t known...', 'Tell more...')),)

myReflections = {"bro": "yo",
                 "yo": "bro"}

myBot = Chat(myPairs, myReflections)
myBot.converse(quit='Bye') 
